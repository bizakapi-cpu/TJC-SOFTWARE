using System.Windows;
using Aurora.App.Services;
using Aurora.App.ViewModels;
using Aurora.Core.Interfaces;
using Aurora.Infrastructure.Database;
using Aurora.Infrastructure.Games;
using Aurora.Infrastructure.Hardware;
using Aurora.Infrastructure.Music;
using Microsoft.Extensions.DependencyInjection;

namespace Aurora.App;

public partial class App : Application
{
    public static IServiceProvider Services { get; private set; } = null!;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var s = new ServiceCollection();
        // Infrastructure
        s.AddSingleton<AuroraDatabase>();
        s.AddSingleton<IGameRepository, GameRepository>();
        s.AddSingleton<IMusicRepository, MusicRepository>();
        s.AddSingleton<IGameScanner, SteamScanner>();
        s.AddSingleton<IGameScanner, EpicScanner>();
        s.AddSingleton<IGameLauncher, GameLauncher>();
        s.AddSingleton<IMusicLibraryImporter, MusicLibraryImporter>();
        s.AddSingleton<IMusicPlayer, NAudioPlayer>();
        s.AddSingleton<IHardwareMonitor, HardwareMonitor>();
        // App
        s.AddSingleton<ThemeService>();
        s.AddSingleton<PlayerViewModel>();
        s.AddSingleton<MainViewModel>();
        s.AddSingleton<GamesViewModel>();
        s.AddSingleton<MusicViewModel>();
        s.AddSingleton<ConnectViewModel>();
        s.AddSingleton<DashboardViewModel>();
        s.AddSingleton<SettingsViewModel>();
        Services = s.BuildServiceProvider();

        Services.GetRequiredService<ThemeService>().LoadSaved();

        var window = new MainWindow { DataContext = Services.GetRequiredService<MainViewModel>() };
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        (Services as IDisposable)?.Dispose();
        base.OnExit(e);
    }
}
