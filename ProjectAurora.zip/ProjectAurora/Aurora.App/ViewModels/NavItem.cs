using CommunityToolkit.Mvvm.ComponentModel;

namespace Aurora.App.ViewModels;

public partial class NavItem(string key, string title, string icon) : ObservableObject
{
    public string Key { get; } = key;
    public string Title { get; } = title;
    public string Icon { get; } = icon;
    [ObservableProperty] private bool _isSelected;
}

/// <summary>Modules die iets moeten starten/stoppen wanneer ze zichtbaar worden (bv. monitoring-timer).</summary>
public interface INavigationAware
{
    void OnNavigatedTo();
    void OnNavigatedFrom();
}
