using System.Windows.Threading;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Aurora.App.ViewModels;

/// <summary>De muziekspeler onderaan. Eén instantie voor de hele app, zodat muziek doorspeelt tijdens navigeren.</summary>
public partial class PlayerViewModel : ObservableObject
{
    private readonly IMusicPlayer _player;
    private readonly DispatcherTimer _timer;
    private readonly Random _rng = new();
    private List<Track> _queue = new();
    private int _index = -1;
    private bool _updating;
    private double _position;

    [ObservableProperty] private Track? _nowPlaying;
    [ObservableProperty] private bool _isPlaying;
    [ObservableProperty] private bool _shuffle;
    [ObservableProperty] private bool _repeat;
    [ObservableProperty] private double _volume = 0.8;
    [ObservableProperty] private double _duration = 1;

    public PlayerViewModel(IMusicPlayer player)
    {
        _player = player;
        _player.Volume = (float)Volume;
        _player.TrackEnded += (_, _) => Advance(auto: true);
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _timer.Tick += (_, _) =>
        {
            _updating = true;
            Position = _player.PositionSeconds;
            _updating = false;
            IsPlaying = _player.IsPlaying;
        };
        _timer.Start();
    }

    public double Position
    {
        get => _position;
        set
        {
            if (!SetProperty(ref _position, value)) return;
            OnPropertyChanged(nameof(PositionText));
            if (!_updating) _player.PositionSeconds = value;
        }
    }

    public string PositionText => TimeSpan.FromSeconds(Position).ToString(@"m\:ss");
    public string DurationText => TimeSpan.FromSeconds(Duration).ToString(@"m\:ss");

    partial void OnVolumeChanged(double value) => _player.Volume = (float)value;
    partial void OnDurationChanged(double value) => OnPropertyChanged(nameof(DurationText));

    public void PlayQueue(IReadOnlyList<Track> queue, Track start)
    {
        _queue = queue.ToList();
        _index = _queue.IndexOf(start);
        if (_index < 0) { _queue.Insert(0, start); _index = 0; }
        PlayCurrent();
    }

    private void PlayCurrent()
    {
        var track = _queue[_index];
        try
        {
            _player.Play(track);
            NowPlaying = track;
            Duration = Math.Max(1, _player.DurationSeconds);
            IsPlaying = true;
        }
        catch
        {
            NowPlaying = null;
            IsPlaying = false;
        }
    }

    [RelayCommand]
    private void PlayPause()
    {
        if (NowPlaying is null) return;
        if (_player.IsPlaying) _player.Pause(); else _player.Resume();
        IsPlaying = _player.IsPlaying;
    }

    [RelayCommand] private void Next() => Advance(auto: false);

    [RelayCommand]
    private void Previous()
    {
        if (_queue.Count == 0) return;
        if (_player.PositionSeconds > 3) { _player.PositionSeconds = 0; return; }
        _index = Math.Max(0, _index - 1);
        PlayCurrent();
    }

    private void Advance(bool auto)
    {
        if (_queue.Count == 0) return;
        if (Shuffle && _queue.Count > 1)
        {
            int next;
            do next = _rng.Next(_queue.Count); while (next == _index);
            _index = next;
        }
        else if (_index + 1 < _queue.Count) _index++;
        else if (Repeat) _index = 0;
        else
        {
            if (auto) { _player.Stop(); IsPlaying = false; }
            return;
        }
        PlayCurrent();
    }
}
