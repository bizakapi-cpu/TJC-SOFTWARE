using System.Collections.ObjectModel;
using System.Windows.Threading;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Aurora.App.ViewModels;

public partial class DashboardViewModel : ObservableObject, INavigationAware
{
    private readonly IHardwareMonitor _hw;
    private readonly DispatcherTimer _timer;
    private bool _busy;

    [ObservableProperty] private string _cpuName = "CPU";
    [ObservableProperty] private double _cpuLoad;
    [ObservableProperty] private string _cpuTemp = "n.v.t.";
    [ObservableProperty] private string _gpuName = "GPU";
    [ObservableProperty] private double _gpuLoad;
    [ObservableProperty] private string _gpuTemp = "n.v.t.";
    [ObservableProperty] private double _ramLoad;
    [ObservableProperty] private string _ramText = "";
    [ObservableProperty] private string _downText = "0.0 Mbps";
    [ObservableProperty] private string _upText = "0.0 Mbps";
    [ObservableProperty] private bool _showTempHint;

    public ObservableCollection<DiskInfo> Disks { get; } = new();
    public ObservableCollection<StartupProgram> Startup { get; } = new();

    public DashboardViewModel(IHardwareMonitor hw)
    {
        _hw = hw;
        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _timer.Tick += async (_, _) => await RefreshAsync();
    }

    // Monitoring draait alleen terwijl het dashboard zichtbaar is.
    public void OnNavigatedTo()
    {
        if (Startup.Count == 0)
            foreach (var s in _hw.GetStartupPrograms()) Startup.Add(s);
        _timer.Start();
        _ = RefreshAsync();
    }

    public void OnNavigatedFrom() => _timer.Stop();

    private async Task RefreshAsync()
    {
        if (_busy) return;
        _busy = true;
        try { Apply(await Task.Run(_hw.Read)); }
        catch { /* sensor tijdelijk niet beschikbaar */ }
        finally { _busy = false; }
    }

    private void Apply(HardwareSnapshot s)
    {
        CpuName = s.CpuName;
        CpuLoad = s.CpuLoad;
        CpuTemp = s.CpuTemp is { } ct ? $"{ct:0} °C" : "n.v.t.";
        GpuName = s.GpuName;
        GpuLoad = s.GpuLoad ?? 0;
        GpuTemp = s.GpuTemp is { } gt ? $"{gt:0} °C" : "n.v.t.";
        RamLoad = s.RamLoad;
        RamText = $"{s.RamUsedGb:0.0} / {s.RamTotalGb:0.0} GB";
        DownText = $"{s.DownMbps:0.0} Mbps";
        UpText = $"{s.UpMbps:0.0} Mbps";
        ShowTempHint = s.CpuTemp is null && s.GpuTemp is null;

        Disks.Clear();
        foreach (var d in s.Disks) Disks.Add(d);
    }
}
