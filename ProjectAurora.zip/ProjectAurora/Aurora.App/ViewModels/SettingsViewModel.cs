using Aurora.App.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Aurora.App.ViewModels;

public partial class SettingsViewModel(ThemeService theme) : ObservableObject
{
    public string Version => "Aurora 1.0.0 (codenaam Project Aurora)";

    [RelayCommand]
    private void SetAccent(string name) => theme.Apply(name);
}
