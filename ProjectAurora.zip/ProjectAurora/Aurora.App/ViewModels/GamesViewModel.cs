using System.Collections.ObjectModel;
using System.IO;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;

namespace Aurora.App.ViewModels;

public partial class GamesViewModel : ObservableObject
{
    private readonly IGameRepository _repo;
    private readonly IEnumerable<IGameScanner> _scanners;
    private readonly IGameLauncher _launcher;
    private List<Game> _all = new();

    public ObservableCollection<Game> Games { get; } = new();
    public ObservableCollection<Game> Recent { get; } = new();

    [ObservableProperty] private string _search = "";
    [ObservableProperty] private bool _onlyFavorites;
    [ObservableProperty] private string _status = "";
    [ObservableProperty] private bool _isEmpty = true;
    [ObservableProperty] private bool _isScanning;
    [ObservableProperty] private bool _hasRecent;

    public GamesViewModel(IGameRepository repo, IEnumerable<IGameScanner> scanners, IGameLauncher launcher)
    {
        _repo = repo; _scanners = scanners; _launcher = launcher;
        _ = LoadAsync();
    }

    partial void OnSearchChanged(string value) => Apply();
    partial void OnOnlyFavoritesChanged(bool value) => Apply();

    private async Task LoadAsync()
    {
        _all = (await _repo.GetAllAsync()).ToList();
        Apply();
    }

    private void Apply()
    {
        var q = _all.AsEnumerable();
        if (OnlyFavorites) q = q.Where(g => g.IsFavorite);
        if (!string.IsNullOrWhiteSpace(Search)) q = q.Where(g => g.Name.Contains(Search, StringComparison.OrdinalIgnoreCase));

        Games.Clear();
        foreach (var g in q.OrderByDescending(g => g.IsFavorite).ThenBy(g => g.Name)) Games.Add(g);
        IsEmpty = Games.Count == 0;

        Recent.Clear();
        foreach (var g in _all.Where(g => g.LastPlayed != null).OrderByDescending(g => g.LastPlayed).Take(6)) Recent.Add(g);
        HasRecent = Recent.Count > 0;
    }

    private static IReadOnlyList<Game> SafeScan(IGameScanner s)
    {
        try { return s.Scan(); } catch { return Array.Empty<Game>(); }
    }

    [RelayCommand]
    private async Task ScanAsync()
    {
        IsScanning = true;
        Status = "Bezig met zoeken naar geïnstalleerde games...";
        var found = await Task.Run(() => _scanners.SelectMany(SafeScan).ToList());
        foreach (var g in found) await _repo.AddOrUpdateAsync(g);
        await LoadAsync();
        Status = $"{found.Count} games gevonden (Steam en Epic).";
        IsScanning = false;
    }

    [RelayCommand]
    private async Task AddManualAsync()
    {
        var dlg = new OpenFileDialog { Filter = "Programma's (*.exe)|*.exe", Title = "Kies het startbestand van de game" };
        if (dlg.ShowDialog() != true) return;
        await _repo.AddOrUpdateAsync(new Game
        {
            Name = Path.GetFileNameWithoutExtension(dlg.FileName),
            LaunchTarget = dlg.FileName,
            Source = "Handmatig"
        });
        await LoadAsync();
    }

    [RelayCommand]
    private async Task LaunchAsync(Game game)
    {
        try
        {
            _launcher.Launch(game);
            game.LastPlayed = DateTime.Now;
            await _repo.SetLastPlayedAsync(game.Id, game.LastPlayed.Value);
            Status = $"{game.Name} wordt gestart...";
            Apply();
        }
        catch (Exception ex) { Status = $"Starten mislukt: {ex.Message}"; }
    }

    [RelayCommand]
    private async Task ToggleFavoriteAsync(Game game)
    {
        game.IsFavorite = !game.IsFavorite;
        await _repo.SetFavoriteAsync(game.Id, game.IsFavorite);
        Apply();
    }

    [RelayCommand]
    private async Task RemoveAsync(Game game)
    {
        await _repo.DeleteAsync(game.Id);
        await LoadAsync();
    }
}
