using CommunityToolkit.Mvvm.ComponentModel;

namespace Aurora.App.ViewModels;

/// <summary>V1.0: alleen de interface (preview). Accounts, chat en servers volgen in V1.1 via Supabase.</summary>
public partial class ConnectViewModel : ObservableObject
{
    public string[] Channels { get; } = ["# welkom", "# algemeen", "# games", "# muziek", "# hulp"];
    public string[] Friends { get; } = ["Nova", "Pixel", "Echo", "Zephyr"];
    public string[] Messages { get; } =
    [
        "Nova: Welkom bij Aurora! 👋",
        "Pixel: Iemand zin in een potje vanavond?",
        "Echo: Ik deel straks mijn nieuwe playlist.",
    ];
}
