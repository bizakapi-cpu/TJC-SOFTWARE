using System.Collections.ObjectModel;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;

namespace Aurora.App.ViewModels;

public partial class MusicViewModel : ObservableObject
{
    private static readonly Playlist LibraryList = new() { Id = 0, Name = "Bibliotheek" };
    private static readonly Playlist FavoritesList = new() { Id = -1, Name = "Favorieten" };

    private readonly IMusicRepository _repo;
    private readonly IMusicLibraryImporter _importer;
    private List<Track> _all = new();

    public PlayerViewModel Player { get; }
    public ObservableCollection<Track> Tracks { get; } = new();
    /// <summary>Alle lijsten inclusief Bibliotheek en Favorieten (voor de zijbalk).</summary>
    public ObservableCollection<Playlist> Playlists { get; } = new();
    /// <summary>Alleen echte, zelfgemaakte afspeellijsten (voor "toevoegen aan").</summary>
    public ObservableCollection<Playlist> UserPlaylists { get; } = new();

    [ObservableProperty] private Playlist? _selectedPlaylist;
    [ObservableProperty] private string _search = "";
    [ObservableProperty] private string _newPlaylistName = "";
    [ObservableProperty] private string _status = "";
    [ObservableProperty] private bool _isEmpty = true;

    public MusicViewModel(IMusicRepository repo, IMusicLibraryImporter importer, PlayerViewModel player)
    {
        _repo = repo; _importer = importer; Player = player;
        _ = LoadAsync();
    }

    partial void OnSelectedPlaylistChanged(Playlist? value) => _ = RefreshAsync();
    partial void OnSearchChanged(string value) => _ = RefreshAsync();

    private async Task LoadAsync()
    {
        _all = (await _repo.GetTracksAsync()).ToList();
        await ReloadPlaylistsAsync();
    }

    private async Task ReloadPlaylistsAsync()
    {
        var keep = SelectedPlaylist?.Id;
        Playlists.Clear(); UserPlaylists.Clear();
        Playlists.Add(LibraryList); Playlists.Add(FavoritesList);
        foreach (var p in await _repo.GetPlaylistsAsync()) { Playlists.Add(p); UserPlaylists.Add(p); }
        SelectedPlaylist = Playlists.FirstOrDefault(p => p.Id == keep) ?? LibraryList;
    }

    private async Task RefreshAsync()
    {
        IEnumerable<Track> src = _all;
        var p = SelectedPlaylist;
        if (p?.Id == -1) src = src.Where(t => t.IsFavorite);
        else if (p is { Id: > 0 })
        {
            var ids = await _repo.GetPlaylistTrackIdsAsync(p.Id);
            var map = _all.ToDictionary(t => t.Id);
            src = ids.Where(map.ContainsKey).Select(i => map[i]);
        }
        if (!string.IsNullOrWhiteSpace(Search))
            src = src.Where(t => t.Title.Contains(Search, StringComparison.OrdinalIgnoreCase)
                              || t.Artist.Contains(Search, StringComparison.OrdinalIgnoreCase)
                              || t.Album.Contains(Search, StringComparison.OrdinalIgnoreCase));

        var list = src.ToList();
        Tracks.Clear();
        foreach (var t in list) Tracks.Add(t);
        IsEmpty = Tracks.Count == 0;
    }

    private async Task ImportAsync(IEnumerable<string> paths)
    {
        Status = "Importeren...";
        var imported = await _importer.ImportAsync(paths);
        await LoadAsync();
        Status = $"{imported.Count} nummers geïmporteerd.";
    }

    [RelayCommand]
    private async Task ImportFilesAsync()
    {
        var dlg = new OpenFileDialog { Multiselect = true, Filter = "Muziek (*.mp3;*.wav;*.flac)|*.mp3;*.wav;*.flac" };
        if (dlg.ShowDialog() == true) await ImportAsync(dlg.FileNames);
    }

    [RelayCommand]
    private async Task ImportFolderAsync()
    {
        var dlg = new OpenFolderDialog { Title = "Kies je muziekmap" };
        if (dlg.ShowDialog() == true) await ImportAsync([dlg.FolderName]);
    }

    [RelayCommand]
    private void Play(Track track) => Player.PlayQueue(Tracks.ToList(), track);

    [RelayCommand]
    private async Task ToggleFavoriteAsync(Track track)
    {
        track.IsFavorite = !track.IsFavorite;
        await _repo.SetFavoriteAsync(track.Id, track.IsFavorite);
        if (SelectedPlaylist?.Id == -1) await RefreshAsync();
    }

    [RelayCommand]
    private async Task CreatePlaylistAsync()
    {
        if (string.IsNullOrWhiteSpace(NewPlaylistName)) return;
        var created = await _repo.CreatePlaylistAsync(NewPlaylistName);
        NewPlaylistName = "";
        await ReloadPlaylistsAsync();
        SelectedPlaylist = Playlists.FirstOrDefault(p => p.Id == created.Id);
    }

    [RelayCommand]
    private async Task DeletePlaylistAsync()
    {
        if (SelectedPlaylist is not { Id: > 0 } p) return;
        await _repo.DeletePlaylistAsync(p.Id);
        SelectedPlaylist = null;
        await ReloadPlaylistsAsync();
    }

    public async Task AddToPlaylistAsync(Track track, Playlist playlist)
    {
        await _repo.AddToPlaylistAsync(playlist.Id, track.Id);
        Status = $"\"{track.Title}\" toegevoegd aan {playlist.Name}.";
        if (SelectedPlaylist?.Id == playlist.Id) await RefreshAsync();
    }
}
