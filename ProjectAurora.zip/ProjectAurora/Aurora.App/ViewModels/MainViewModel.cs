using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.DependencyInjection;

namespace Aurora.App.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly IServiceProvider _sp;
    private readonly Dictionary<string, ObservableObject> _cache = new();

    public IReadOnlyList<NavItem> Items { get; } =
    [
        new("Games", "Games", "\uE7FC"),
        new("Music", "Music", "\uE8D6"),
        new("Connect", "Connect", "\uE716"),
        new("Dashboard", "Dashboard", "\uE9D9"),
    ];

    public IReadOnlyList<NavItem> FooterItems { get; } = [new("Settings", "Instellingen", "\uE713")];

    public PlayerViewModel Player { get; }

    [ObservableProperty] private ObservableObject? _current;

    public MainViewModel(IServiceProvider sp, PlayerViewModel player)
    {
        _sp = sp;
        Player = player;
        Navigate("Games");
    }

    [RelayCommand]
    private void Navigate(string key)
    {
        (Current as INavigationAware)?.OnNavigatedFrom();

        foreach (var item in Items.Concat(FooterItems)) item.IsSelected = item.Key == key;

        // Module wordt pas aangemaakt bij eerste gebruik (lazy loading).
        if (!_cache.TryGetValue(key, out var vm))
        {
            vm = key switch
            {
                "Games" => _sp.GetRequiredService<GamesViewModel>(),
                "Music" => _sp.GetRequiredService<MusicViewModel>(),
                "Connect" => _sp.GetRequiredService<ConnectViewModel>(),
                "Dashboard" => _sp.GetRequiredService<DashboardViewModel>(),
                "Settings" => _sp.GetRequiredService<SettingsViewModel>(),
                _ => throw new ArgumentOutOfRangeException(nameof(key))
            };
            _cache[key] = vm;
        }
        Current = vm;
        (vm as INavigationAware)?.OnNavigatedTo();
    }
}
