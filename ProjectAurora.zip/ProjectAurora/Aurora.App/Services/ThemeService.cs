using System.IO;
using System.Windows;
using System.Windows.Media;

namespace Aurora.App.Services;

/// <summary>Wisselt de accentkleur tijdens runtime en onthoudt de keuze.</summary>
public sealed class ThemeService
{
    private static readonly Dictionary<string, (string Accent, string Foreground)> Accents = new()
    {
        ["Violet"] = ("#8B5CF6", "#FFFFFF"),
        ["Blauw"] = ("#0A84FF", "#FFFFFF"),
        ["Zilver"] = ("#D1D1D6", "#1C1C1E"),
    };

    private static string SettingsPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Aurora", "accent.txt");

    public void LoadSaved()
    {
        try { Apply(File.Exists(SettingsPath) ? File.ReadAllText(SettingsPath).Trim() : "Violet", save: false); }
        catch { Apply("Violet", save: false); }
    }

    public void Apply(string name, bool save = true)
    {
        if (!Accents.TryGetValue(name, out var a)) { name = "Violet"; a = Accents[name]; }
        var res = Application.Current.Resources;
        res["AccentBrush"] = Make(a.Accent);
        res["AccentForegroundBrush"] = Make(a.Foreground);
        if (!save) return;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
            File.WriteAllText(SettingsPath, name);
        }
        catch { /* niet kritiek */ }
    }

    private static SolidColorBrush Make(string hex)
    {
        var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        b.Freeze();
        return b;
    }
}
