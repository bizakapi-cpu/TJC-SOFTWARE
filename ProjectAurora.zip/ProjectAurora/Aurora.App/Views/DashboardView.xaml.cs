using System.Windows.Controls;

namespace Aurora.App.Views;

public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}
