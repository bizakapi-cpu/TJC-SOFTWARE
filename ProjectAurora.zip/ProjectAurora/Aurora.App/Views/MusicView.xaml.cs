using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Aurora.App.ViewModels;
using Aurora.Core.Models;

namespace Aurora.App.Views;

public partial class MusicView : UserControl
{
    public MusicView() => InitializeComponent();

    private void AddButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { ContextMenu: { } menu } button)
        {
            menu.PlacementTarget = button;
            menu.Placement = PlacementMode.Bottom;
            menu.IsOpen = true;
        }
    }

    private void AddToPlaylist_Click(object sender, RoutedEventArgs e)
    {
        if (sender is MenuItem { DataContext: Playlist playlist } item
            && ItemsControl.ItemsControlFromItemContainer(item) is ContextMenu { PlacementTarget: FrameworkElement { DataContext: Track track } }
            && DataContext is MusicViewModel vm)
        {
            _ = vm.AddToPlaylistAsync(track, playlist);
        }
    }
}
