using System.Windows.Controls;

namespace Aurora.App.Views;

public partial class ConnectView : UserControl
{
    public ConnectView() => InitializeComponent();
}
