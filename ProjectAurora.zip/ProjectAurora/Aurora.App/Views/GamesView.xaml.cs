using System.Windows.Controls;

namespace Aurora.App.Views;

public partial class GamesView : UserControl
{
    public GamesView() => InitializeComponent();
}
