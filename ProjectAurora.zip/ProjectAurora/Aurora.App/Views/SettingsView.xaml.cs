using System.Windows.Controls;

namespace Aurora.App.Views;

public partial class SettingsView : UserControl
{
    public SettingsView() => InitializeComponent();
}
