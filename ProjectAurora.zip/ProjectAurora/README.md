# Project Aurora (werknaam)

Gratis all-in-one Windows-app met vier modules: **Games**, **Music**, **Connect** en **PC Dashboard**.
Stijl: Dark macOS, violet accent, compacte sidebar. Alles in V1.0 werkt lokaal en offline.

## Starten (ontwikkeling)
Vereist: Windows 10/11, .NET 10 SDK, Visual Studio 2026 (of 2022 17.13+) met de workload ".NET desktop development".

```
dotnet restore
dotnet build
dotnet run --project Aurora.App
```
Voor CPU/GPU-temperaturen: start Aurora (of Visual Studio) als beheerder.

## Architectuur
```
Aurora.App            WPF + XAML, MVVM (CommunityToolkit.Mvvm), dependency injection
  Views/              GamesView, MusicView, ConnectView, DashboardView, SettingsView
  ViewModels/         één ViewModel per module + PlayerViewModel (spelerbalk) + MainViewModel (navigatie)
  Themes/             Colors.xaml, Typography.xaml, Styles.xaml  (alle kleuren op één plek)
  Services/           ThemeService (accentkleur wisselen + onthouden)
Aurora.Core           Modellen en interfaces. Geen afhankelijkheid van Windows of UI.
Aurora.Infrastructure Implementaties: SQLite, Steam/Epic-scanners, NAudio, TagLibSharp, LibreHardwareMonitor
Aurora.Tests          xUnit-tests (Steam-parser, repositories)
installer/            Inno Setup-script voor AuroraSetup.exe
```
Afhankelijkheden lopen één kant op: `App → Infrastructure → Core`. Nieuwe bronnen (bijv. Spotify, GOG, Supabase-chat)
voeg je toe door een interface uit Core te implementeren in Infrastructure en die te registreren in `App.xaml.cs`.

Modules worden lazy aangemaakt (`MainViewModel.Navigate`). De dashboard-timer draait alleen als het dashboard zichtbaar is.

## Wat zit in V1.0
- Sidebar-navigatie met vier modules + instellingen, spelerbalk onderaan
- Games: Steam- en Epic-detectie, handmatig toevoegen, starten, favorieten, recent gespeeld, zoeken
- Music: MP3/WAV/FLAC importeren (tags via TagLibSharp), zoeken, afspeellijsten, favorieten, shuffle, repeat, volume
- Dashboard: CPU, GPU, RAM, netwerk, schijven, opstartprogramma's (alleen lezen)
- Connect: interface-preview (nog geen backend)
- Instellingen: accentkleur (violet, blauw, zilver)

## Roadmap V1.1
1. Accounts en chat via Supabase (Auth + Realtime), moderatie en rapportages
2. Spotify-koppeling via de officiële API/SDK (let op: afspelen vereist Spotify Premium en hun voorwaarden)
3. Automatische updates
4. Lichte modus en volledig zelf instelbare accentkleur

## Uitdelen aan de community (automatisch)
De workflow in `.github/workflows/release.yml` bouwt Aurora op een Windows-server van GitHub en publiceert de installer.

1. Maak een gratis account op github.com en een nieuwe repository (bijv. `aurora`).
2. Upload de inhoud van deze map naar de repository (GitHub Desktop, of `git push`).
3. Kijk onder het tabblad **Actions**: de eerste build draait automatisch. Faalt hij, dan staat daar de foutmelding.
4. Als de build groen is, maak je een release met een tag:
   ```
   git tag v1.0.0
   git push origin v1.0.0
   ```
5. Na een paar minuten staat onder **Releases** de download:
   - `AuroraSetup.exe` (installer, geen .NET nodig)
   - `Aurora-portable.zip` (uitpakken en starten)
6. Deel de link `https://github.com/<jouw-naam>/aurora/releases/latest` met de community.

Zonder code signing toont Windows SmartScreen bij de eerste start "Onbekende uitgever" (klik "Meer informatie" en dan "Toch uitvoeren").
Een certificaat (bijv. Azure Trusted Signing) lost dat op.

## Let op
Deze code is geschreven zonder compiler (WPF draait alleen op Windows). Verwacht dat je bij de eerste build
hooguit kleine foutjes moet fixen, zoals pakketversies. Icoon-glyphs komen uit Segoe Fluent Icons en zijn makkelijk te wisselen.
