; Inno Setup 6 - maakt AuroraSetup.exe van de self-contained publish-map.
#define AppName "Aurora"
#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif

[Setup]
AppId={{8F3A2C1E-6B4D-4E7A-9A25-3D1C5B7E9F40}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Project Aurora
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
OutputDir=..\dist
OutputBaseFilename=AuroraSetup
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
WizardStyle=modern
UninstallDisplayIcon={app}\Aurora.exe

[Languages]
Name: "dutch"; MessagesFile: "compiler:Languages\Dutch.isl"

[Tasks]
Name: "desktopicon"; Description: "Snelkoppeling op het bureaublad"; Flags: unchecked

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\Aurora.exe"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\Aurora.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Aurora.exe"; Description: "Aurora starten"; Flags: nowait postinstall skipifsilent
