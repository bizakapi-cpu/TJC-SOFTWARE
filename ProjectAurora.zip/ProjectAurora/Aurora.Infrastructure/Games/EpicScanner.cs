using System.Text.Json;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;

namespace Aurora.Infrastructure.Games;

public sealed class EpicScanner : IGameScanner
{
    public string Name => "Epic";

    public IReadOnlyList<Game> Scan()
    {
        var result = new List<Game>();
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "Epic", "EpicGamesLauncher", "Data", "Manifests");
        if (!Directory.Exists(dir)) return result;

        foreach (var file in Directory.EnumerateFiles(dir, "*.item"))
        {
            try
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(file));
                var root = doc.RootElement;
                var name = root.GetProperty("DisplayName").GetString();
                var location = root.GetProperty("InstallLocation").GetString();
                var exe = root.GetProperty("LaunchExecutable").GetString();
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(location) || string.IsNullOrWhiteSpace(exe)) continue;
                var path = Path.Combine(location, exe);
                if (File.Exists(path)) result.Add(new Game { Name = name, Source = "Epic", LaunchTarget = path });
            }
            catch { /* kapotte manifest overslaan */ }
        }
        return result;
    }
}
