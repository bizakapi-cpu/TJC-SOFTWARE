using System.Diagnostics;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;

namespace Aurora.Infrastructure.Games;

public sealed class GameLauncher : IGameLauncher
{
    public void Launch(Game game)
    {
        var psi = new ProcessStartInfo(game.LaunchTarget) { UseShellExecute = true };
        if (File.Exists(game.LaunchTarget))
            psi.WorkingDirectory = Path.GetDirectoryName(game.LaunchTarget)!;
        Process.Start(psi);
    }
}
