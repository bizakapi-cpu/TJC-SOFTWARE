using System.Text.RegularExpressions;

namespace Aurora.Infrastructure.Games;

public record SteamApp(string AppId, string Name);

/// <summary>Minimale parser voor Valve's key/value-formaat (libraryfolders.vdf en appmanifest_*.acf).</summary>
public static class SteamParser
{
    private static readonly Regex Pair = new("\"(?<k>[^\"]+)\"\\s+\"(?<v>(?:[^\"\\\\]|\\\\.)*)\"", RegexOptions.Compiled);

    public static IEnumerable<string> ParseLibraryPaths(string vdf) =>
        Pair.Matches(vdf).Where(m => m.Groups["k"].Value == "path")
            .Select(m => m.Groups["v"].Value.Replace(@"\\", @"\"));

    public static SteamApp? ParseManifest(string acf)
    {
        string? id = null, name = null;
        foreach (Match m in Pair.Matches(acf))
        {
            var k = m.Groups["k"].Value;
            if (k == "appid") id ??= m.Groups["v"].Value;
            else if (k == "name") name ??= m.Groups["v"].Value;
        }
        return id is not null && name is not null ? new SteamApp(id, name) : null;
    }
}
