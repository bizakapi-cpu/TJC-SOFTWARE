using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using Microsoft.Win32;

namespace Aurora.Infrastructure.Games;

public sealed class SteamScanner : IGameScanner
{
    public string Name => "Steam";

    private static readonly string[] Ignore = ["Steamworks Common Redistributables", "Proton", "Steam Linux Runtime"];

    public IReadOnlyList<Game> Scan()
    {
        var result = new List<Game>();
        var steam = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")?.GetValue("SteamPath") as string;
        if (string.IsNullOrEmpty(steam)) return result;
        steam = steam.Replace('/', '\\');

        var libraries = new List<string> { steam };
        var vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
        if (File.Exists(vdf)) libraries.AddRange(SteamParser.ParseLibraryPaths(File.ReadAllText(vdf)));

        foreach (var lib in libraries.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var dir = Path.Combine(lib, "steamapps");
            if (!Directory.Exists(dir)) continue;
            foreach (var file in Directory.EnumerateFiles(dir, "appmanifest_*.acf"))
            {
                var app = SteamParser.ParseManifest(File.ReadAllText(file));
                if (app is null || Ignore.Any(i => app.Name.StartsWith(i, StringComparison.OrdinalIgnoreCase))) continue;
                result.Add(new Game { Name = app.Name, Source = "Steam", ExternalId = app.AppId, LaunchTarget = $"steam://rungameid/{app.AppId}" });
            }
        }
        return result;
    }
}
