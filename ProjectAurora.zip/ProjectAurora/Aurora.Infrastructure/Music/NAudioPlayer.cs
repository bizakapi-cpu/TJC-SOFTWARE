using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using NAudio.Wave;

namespace Aurora.Infrastructure.Music;

public sealed class NAudioPlayer : IMusicPlayer, IDisposable
{
    private WaveOutEvent? _out;
    private AudioFileReader? _reader;
    private float _volume = 0.8f;

    public event EventHandler? TrackEnded;

    public bool IsPlaying => _out?.PlaybackState == PlaybackState.Playing;
    public double DurationSeconds => _reader?.TotalTime.TotalSeconds ?? 0;

    public double PositionSeconds
    {
        get => _reader?.CurrentTime.TotalSeconds ?? 0;
        set { if (_reader != null) _reader.CurrentTime = TimeSpan.FromSeconds(Math.Clamp(value, 0, DurationSeconds)); }
    }

    public float Volume
    {
        get => _volume;
        set { _volume = Math.Clamp(value, 0f, 1f); if (_reader != null) _reader.Volume = _volume; }
    }

    public void Play(Track track)
    {
        Stop();
        _reader = new AudioFileReader(track.Path) { Volume = _volume };
        _out = new WaveOutEvent();
        _out.Init(_reader);
        _out.PlaybackStopped += OnStopped;
        _out.Play();
    }

    public void Pause() => _out?.Pause();
    public void Resume() => _out?.Play();

    public void Stop()
    {
        if (_out != null)
        {
            _out.PlaybackStopped -= OnStopped;
            _out.Stop();
            _out.Dispose();
            _out = null;
        }
        _reader?.Dispose();
        _reader = null;
    }

    private void OnStopped(object? sender, StoppedEventArgs e)
    {
        if (_reader != null && _reader.Position >= _reader.Length) TrackEnded?.Invoke(this, EventArgs.Empty);
    }

    public void Dispose() => Stop();
}
