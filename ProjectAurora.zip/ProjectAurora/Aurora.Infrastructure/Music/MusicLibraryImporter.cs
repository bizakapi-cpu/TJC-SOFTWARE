using Aurora.Core.Interfaces;
using Aurora.Core.Models;

namespace Aurora.Infrastructure.Music;

public sealed class MusicLibraryImporter(IMusicRepository repo) : IMusicLibraryImporter
{
    private static readonly HashSet<string> Extensions = new(StringComparer.OrdinalIgnoreCase) { ".mp3", ".wav", ".flac" };

    public async Task<IReadOnlyList<Track>> ImportAsync(IEnumerable<string> paths)
    {
        var files = paths.SelectMany(p => Directory.Exists(p)
                ? Directory.EnumerateFiles(p, "*.*", SearchOption.AllDirectories)
                : [p])
            .Where(f => Extensions.Contains(System.IO.Path.GetExtension(f)))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var imported = new List<Track>();
        foreach (var file in files)
        {
            try
            {
                var track = await Task.Run(() => ReadTags(file));
                imported.Add(await repo.AddTrackAsync(track));
            }
            catch { /* onleesbaar bestand overslaan */ }
        }
        return imported;
    }

    private static Track ReadTags(string file)
    {
        using var tl = TagLib.File.Create(file);
        return new Track
        {
            Path = file,
            Title = string.IsNullOrWhiteSpace(tl.Tag.Title) ? System.IO.Path.GetFileNameWithoutExtension(file) : tl.Tag.Title,
            Artist = tl.Tag.FirstPerformer ?? "Onbekende artiest",
            Album = tl.Tag.Album ?? "Onbekend album",
            DurationSeconds = tl.Properties.Duration.TotalSeconds
        };
    }
}
