using System.Net.NetworkInformation;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;
using LibreHardwareMonitor.Hardware;
using Microsoft.Win32;

namespace Aurora.Infrastructure.Hardware;

/// <summary>Lichtgewicht monitoring. Temperaturen vereisen beheerdersrechten; zonder blijven die waarden leeg.</summary>
public sealed class HardwareMonitor : IHardwareMonitor
{
    private readonly Computer _pc = new() { IsCpuEnabled = true, IsGpuEnabled = true, IsMemoryEnabled = true };
    private long _lastRx, _lastTx;
    private DateTime _lastNet = DateTime.MinValue;

    public HardwareMonitor()
    {
        try { _pc.Open(); } catch { /* monitoring blijft beperkt */ }
    }

    public HardwareSnapshot Read()
    {
        string cpuName = "CPU", gpuName = "Geen GPU gevonden";
        float cpuLoad = 0, ramLoad = 0;
        float? cpuTemp = null, gpuLoad = null, gpuTemp = null;
        double ramUsed = 0, ramAvail = 0;
        var gpuIsIntel = true;

        foreach (var hw in _pc.Hardware)
        {
            hw.Update();
            switch (hw.HardwareType)
            {
                case HardwareType.Cpu:
                    cpuName = hw.Name;
                    foreach (var s in hw.Sensors)
                    {
                        if (s.SensorType == SensorType.Load && s.Name == "CPU Total") cpuLoad = s.Value ?? 0;
                        else if (s.SensorType == SensorType.Temperature && s.Value.HasValue &&
                                 (cpuTemp is null || s.Name.Contains("Package") || s.Name.Contains("Tctl")))
                            cpuTemp = s.Value;
                    }
                    break;

                case HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel:
                    var intel = hw.HardwareType == HardwareType.GpuIntel;
                    if (gpuName != "Geen GPU gevonden" && !(gpuIsIntel && !intel)) break; // voorkeur voor discrete GPU
                    gpuName = hw.Name; gpuIsIntel = intel; gpuLoad = null; gpuTemp = null;
                    foreach (var s in hw.Sensors)
                    {
                        if (s.SensorType == SensorType.Load && s.Name == "GPU Core") gpuLoad = s.Value;
                        else if (s.SensorType == SensorType.Temperature && s.Name == "GPU Core") gpuTemp = s.Value;
                    }
                    break;

                case HardwareType.Memory:
                    foreach (var s in hw.Sensors)
                    {
                        if (s.SensorType == SensorType.Load && s.Name == "Memory") ramLoad = s.Value ?? 0;
                        else if (s.SensorType == SensorType.Data && s.Name == "Memory Used") ramUsed = s.Value ?? 0;
                        else if (s.SensorType == SensorType.Data && s.Name == "Memory Available") ramAvail = s.Value ?? 0;
                    }
                    break;
            }
        }

        var (down, up) = ReadNetwork();
        return new HardwareSnapshot(cpuName, cpuLoad, cpuTemp, gpuName, gpuLoad, gpuTemp,
            ramLoad, ramUsed, ramUsed + ramAvail, down, up, ReadDisks());
    }

    private (double down, double up) ReadNetwork()
    {
        long rx = 0, tx = 0;
        foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus != OperationalStatus.Up ||
                nic.NetworkInterfaceType is NetworkInterfaceType.Loopback or NetworkInterfaceType.Tunnel) continue;
            var st = nic.GetIPv4Statistics();
            rx += st.BytesReceived; tx += st.BytesSent;
        }
        var now = DateTime.UtcNow;
        double down = 0, up = 0;
        if (_lastNet != DateTime.MinValue)
        {
            var secs = (now - _lastNet).TotalSeconds;
            if (secs > 0) { down = (rx - _lastRx) * 8 / 1e6 / secs; up = (tx - _lastTx) * 8 / 1e6 / secs; }
        }
        (_lastRx, _lastTx, _lastNet) = (rx, tx, now);
        return (Math.Max(0, down), Math.Max(0, up));
    }

    private static List<DiskInfo> ReadDisks() =>
        DriveInfo.GetDrives().Where(d => d.IsReady && d.DriveType == DriveType.Fixed)
            .Select(d => new DiskInfo(d.Name.TrimEnd('\\'), (d.TotalSize - d.AvailableFreeSpace) / 1e9, d.TotalSize / 1e9))
            .ToList();

    public IReadOnlyList<StartupProgram> GetStartupPrograms()
    {
        var list = new List<StartupProgram>();
        foreach (var (hive, scope) in new[] { (Registry.CurrentUser, "Gebruiker"), (Registry.LocalMachine, "Alle gebruikers") })
        {
            using var key = hive.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run");
            if (key is null) continue;
            foreach (var name in key.GetValueNames())
                list.Add(new StartupProgram(name, key.GetValue(name)?.ToString() ?? "", scope));
        }
        return list;
    }

    public void Dispose() { try { _pc.Close(); } catch { } }
}
