using System.Globalization;
using Aurora.Core.Interfaces;
using Aurora.Core.Models;

namespace Aurora.Infrastructure.Database;

public sealed class GameRepository(AuroraDatabase db) : IGameRepository
{
    public async Task<IReadOnlyList<Game>> GetAllAsync()
    {
        var list = new List<Game>();
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,Name,LaunchTarget,Source,ExternalId,IsFavorite,LastPlayed FROM Games ORDER BY Name COLLATE NOCASE";
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            list.Add(new Game
            {
                Id = r.GetInt32(0), Name = r.GetString(1), LaunchTarget = r.GetString(2),
                Source = r.GetString(3), ExternalId = r.GetString(4), IsFavorite = r.GetInt32(5) == 1,
                LastPlayed = r.IsDBNull(6) ? null : DateTime.Parse(r.GetString(6), null, DateTimeStyles.RoundtripKind)
            });
        }
        return list;
    }

    public async Task<Game> AddOrUpdateAsync(Game g)
    {
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = """
            INSERT INTO Games(Name,LaunchTarget,Source,ExternalId) VALUES($n,$t,$s,$e)
            ON CONFLICT(Source,LaunchTarget) DO UPDATE SET Name=excluded.Name
            RETURNING Id;
            """;
        cmd.With("$n", g.Name).With("$t", g.LaunchTarget).With("$s", g.Source).With("$e", g.ExternalId);
        g.Id = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        return g;
    }

    public Task SetFavoriteAsync(int id, bool favorite) =>
        Exec("UPDATE Games SET IsFavorite=$v WHERE Id=$id", ("$v", favorite ? 1 : 0), ("$id", id));

    public Task SetLastPlayedAsync(int id, DateTime when) =>
        Exec("UPDATE Games SET LastPlayed=$v WHERE Id=$id", ("$v", when.ToString("o")), ("$id", id));

    public Task DeleteAsync(int id) => Exec("DELETE FROM Games WHERE Id=$id", ("$id", id));

    private async Task Exec(string sql, params (string, object)[] ps)
    {
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        foreach (var (n, v) in ps) cmd.With(n, v);
        await cmd.ExecuteNonQueryAsync();
    }
}
