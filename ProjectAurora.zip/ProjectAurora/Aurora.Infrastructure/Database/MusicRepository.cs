using Aurora.Core.Interfaces;
using Aurora.Core.Models;

namespace Aurora.Infrastructure.Database;

public sealed class MusicRepository(AuroraDatabase db) : IMusicRepository
{
    public async Task<IReadOnlyList<Track>> GetTracksAsync()
    {
        var list = new List<Track>();
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,Title,Artist,Album,Path,DurationSeconds,IsFavorite FROM Tracks ORDER BY Artist COLLATE NOCASE, Album COLLATE NOCASE, Title COLLATE NOCASE";
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new Track
            {
                Id = r.GetInt32(0), Title = r.GetString(1), Artist = r.GetString(2), Album = r.GetString(3),
                Path = r.GetString(4), DurationSeconds = r.GetDouble(5), IsFavorite = r.GetInt32(6) == 1
            });
        return list;
    }

    public async Task<Track> AddTrackAsync(Track t)
    {
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = """
            INSERT INTO Tracks(Title,Artist,Album,Path,DurationSeconds) VALUES($t,$a,$al,$p,$d)
            ON CONFLICT(Path) DO UPDATE SET Title=excluded.Title, Artist=excluded.Artist,
                Album=excluded.Album, DurationSeconds=excluded.DurationSeconds
            RETURNING Id;
            """;
        cmd.With("$t", t.Title).With("$a", t.Artist).With("$al", t.Album).With("$p", t.Path).With("$d", t.DurationSeconds);
        t.Id = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        return t;
    }

    public Task SetFavoriteAsync(int trackId, bool favorite) =>
        Exec("UPDATE Tracks SET IsFavorite=$v WHERE Id=$id", ("$v", favorite ? 1 : 0), ("$id", trackId));

    public async Task<IReadOnlyList<Playlist>> GetPlaylistsAsync()
    {
        var list = new List<Playlist>();
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,Name FROM Playlists ORDER BY Name COLLATE NOCASE";
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(new Playlist { Id = r.GetInt32(0), Name = r.GetString(1) });
        return list;
    }

    public async Task<Playlist> CreatePlaylistAsync(string name)
    {
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO Playlists(Name) VALUES($n) RETURNING Id";
        cmd.With("$n", name.Trim());
        return new Playlist { Id = Convert.ToInt32(await cmd.ExecuteScalarAsync()), Name = name.Trim() };
    }

    public async Task DeletePlaylistAsync(int id)
    {
        await Exec("DELETE FROM PlaylistTracks WHERE PlaylistId=$id", ("$id", id));
        await Exec("DELETE FROM Playlists WHERE Id=$id", ("$id", id));
    }

    public Task AddToPlaylistAsync(int playlistId, int trackId) => Exec("""
        INSERT OR IGNORE INTO PlaylistTracks(PlaylistId,TrackId,Position)
        VALUES($p,$t,(SELECT IFNULL(MAX(Position),0)+1 FROM PlaylistTracks WHERE PlaylistId=$p))
        """, ("$p", playlistId), ("$t", trackId));

    public async Task<IReadOnlyList<int>> GetPlaylistTrackIdsAsync(int playlistId)
    {
        var ids = new List<int>();
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT TrackId FROM PlaylistTracks WHERE PlaylistId=$p ORDER BY Position";
        cmd.With("$p", playlistId);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) ids.Add(r.GetInt32(0));
        return ids;
    }

    private async Task Exec(string sql, params (string, object)[] ps)
    {
        await using var c = db.Open();
        await using var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        foreach (var (n, v) in ps) cmd.With(n, v);
        await cmd.ExecuteNonQueryAsync();
    }
}
