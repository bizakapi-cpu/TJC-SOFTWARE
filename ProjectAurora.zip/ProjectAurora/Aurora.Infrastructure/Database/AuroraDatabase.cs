using Microsoft.Data.Sqlite;

namespace Aurora.Infrastructure.Database;

/// <summary>Lokale SQLite-opslag in %LocalAppData%\Aurora\aurora.db. Alles blijft offline.</summary>
public sealed class AuroraDatabase
{
    private readonly string _connectionString;

    public AuroraDatabase(string? path = null)
    {
        path ??= Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Aurora", "aurora.db");
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        _connectionString = $"Data Source={path}";
        Initialize();
    }

    public SqliteConnection Open()
    {
        var c = new SqliteConnection(_connectionString);
        c.Open();
        return c;
    }

    private void Initialize()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS Games(
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name TEXT NOT NULL,
                LaunchTarget TEXT NOT NULL,
                Source TEXT NOT NULL,
                ExternalId TEXT NOT NULL DEFAULT '',
                IsFavorite INTEGER NOT NULL DEFAULT 0,
                LastPlayed TEXT NULL,
                UNIQUE(Source, LaunchTarget));
            CREATE TABLE IF NOT EXISTS Tracks(
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Title TEXT NOT NULL, Artist TEXT NOT NULL, Album TEXT NOT NULL,
                Path TEXT NOT NULL UNIQUE,
                DurationSeconds REAL NOT NULL,
                IsFavorite INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS Playlists(
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS PlaylistTracks(
                PlaylistId INTEGER NOT NULL, TrackId INTEGER NOT NULL, Position INTEGER NOT NULL,
                PRIMARY KEY(PlaylistId, TrackId));
            """;
        cmd.ExecuteNonQuery();
    }
}

internal static class SqlExtensions
{
    public static SqliteCommand With(this SqliteCommand cmd, string name, object? value)
    {
        cmd.Parameters.AddWithValue(name, value ?? DBNull.Value);
        return cmd;
    }
}
