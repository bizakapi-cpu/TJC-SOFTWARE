using CommunityToolkit.Mvvm.ComponentModel;

namespace Aurora.Core.Models;

public partial class Game : ObservableObject
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    /// <summary>Pad naar een .exe of een URI zoals steam://rungameid/123.</summary>
    public string LaunchTarget { get; set; } = "";
    public string Source { get; set; } = "Handmatig";
    public string ExternalId { get; set; } = "";
    [ObservableProperty] private bool _isFavorite;
    [ObservableProperty] private DateTime? _lastPlayed;
    public string Initial => string.IsNullOrWhiteSpace(Name) ? "?" : Name[..1].ToUpperInvariant();
}

public partial class Track : ObservableObject
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Artist { get; set; } = "";
    public string Album { get; set; } = "";
    public string Path { get; set; } = "";
    public double DurationSeconds { get; set; }
    [ObservableProperty] private bool _isFavorite;
    public string DurationText => TimeSpan.FromSeconds(DurationSeconds)
        .ToString(DurationSeconds >= 3600 ? @"h\:mm\:ss" : @"m\:ss");
}

public class Playlist
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
}

public record DiskInfo(string Name, double UsedGb, double TotalGb)
{
    public double Percent => TotalGb <= 0 ? 0 : UsedGb / TotalGb * 100;
    public string Text => $"{UsedGb:0} / {TotalGb:0} GB";
}

public record StartupProgram(string Name, string Command, string Scope);

public record HardwareSnapshot(
    string CpuName, float CpuLoad, float? CpuTemp,
    string GpuName, float? GpuLoad, float? GpuTemp,
    float RamLoad, double RamUsedGb, double RamTotalGb,
    double DownMbps, double UpMbps,
    IReadOnlyList<DiskInfo> Disks);
