using Aurora.Core.Models;

namespace Aurora.Core.Interfaces;

public interface IGameRepository
{
    Task<IReadOnlyList<Game>> GetAllAsync();
    Task<Game> AddOrUpdateAsync(Game game);
    Task SetFavoriteAsync(int id, bool favorite);
    Task SetLastPlayedAsync(int id, DateTime when);
    Task DeleteAsync(int id);
}

/// <summary>Detecteert games van één launcher (Steam, Epic, ...). Nieuwe launcher = nieuwe implementatie.</summary>
public interface IGameScanner
{
    string Name { get; }
    IReadOnlyList<Game> Scan();
}

public interface IGameLauncher { void Launch(Game game); }

public interface IMusicRepository
{
    Task<IReadOnlyList<Track>> GetTracksAsync();
    Task<Track> AddTrackAsync(Track track);
    Task SetFavoriteAsync(int trackId, bool favorite);
    Task<IReadOnlyList<Playlist>> GetPlaylistsAsync();
    Task<Playlist> CreatePlaylistAsync(string name);
    Task DeletePlaylistAsync(int playlistId);
    Task AddToPlaylistAsync(int playlistId, int trackId);
    Task<IReadOnlyList<int>> GetPlaylistTrackIdsAsync(int playlistId);
}

public interface IMusicLibraryImporter
{
    /// <summary>Importeert bestanden of mappen (recursief). Ondersteund: mp3, wav, flac.</summary>
    Task<IReadOnlyList<Track>> ImportAsync(IEnumerable<string> paths);
}

/// <summary>Lokale afspeler nu; Spotify e.d. komen later als extra implementaties (V1.1).</summary>
public interface IMusicPlayer
{
    event EventHandler? TrackEnded;
    bool IsPlaying { get; }
    double PositionSeconds { get; set; }
    double DurationSeconds { get; }
    float Volume { get; set; }
    void Play(Track track);
    void Pause();
    void Resume();
    void Stop();
}

public interface IHardwareMonitor : IDisposable
{
    HardwareSnapshot Read();
    IReadOnlyList<StartupProgram> GetStartupPrograms();
}
