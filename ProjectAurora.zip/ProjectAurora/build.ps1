# Bouwt Aurora en maakt de installer. Uitvoeren in PowerShell vanuit de projectmap.
$ErrorActionPreference = "Stop"

dotnet test Aurora.Tests
dotnet publish Aurora.App -c Release -r win-x64 --self-contained true -o publish

$iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if (Test-Path $iscc) { & $iscc installer\Aurora.iss; Write-Host "Klaar: dist\AuroraSetup.exe" }
else { Write-Host "Publish klaar in .\publish. Installeer Inno Setup 6 om AuroraSetup.exe te maken." }
