using Aurora.Core.Models;
using Aurora.Infrastructure.Database;
using Aurora.Infrastructure.Games;
using Xunit;

namespace Aurora.Tests;

public class SteamParserTests
{
    [Fact]
    public void ParseLibraryPaths_ReadsAllLibraries()
    {
        const string vdf = """
            "libraryfolders" { "0" { "path" "C:\\Program Files (x86)\\Steam" } "1" { "path" "D:\\SteamLibrary" } }
            """;
        var paths = SteamParser.ParseLibraryPaths(vdf).ToList();
        Assert.Equal([@"C:\Program Files (x86)\Steam", @"D:\SteamLibrary"], paths);
    }

    [Fact]
    public void ParseManifest_ReturnsIdAndName()
    {
        const string acf = "\"AppState\" { \"appid\" \"620\" \"name\" \"Portal 2\" \"installdir\" \"Portal 2\" }";
        var app = SteamParser.ParseManifest(acf);
        Assert.Equal(new SteamApp("620", "Portal 2"), app);
    }

    [Fact]
    public void ParseManifest_WithoutName_ReturnsNull() =>
        Assert.Null(SteamParser.ParseManifest("\"AppState\" { \"appid\" \"1\" }"));
}

public class RepositoryTests : IDisposable
{
    private readonly string _file = Path.Combine(Path.GetTempPath(), $"aurora-test-{Guid.NewGuid():N}.db");
    public void Dispose() { Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools(); try { File.Delete(_file); } catch { } }

    [Fact]
    public async Task Playlist_KeepsTrackOrder_AndIgnoresDuplicates()
    {
        var repo = new MusicRepository(new AuroraDatabase(_file));
        var a = await repo.AddTrackAsync(new Track { Title = "A", Artist = "x", Album = "y", Path = "a.mp3" });
        var b = await repo.AddTrackAsync(new Track { Title = "B", Artist = "x", Album = "y", Path = "b.mp3" });
        var pl = await repo.CreatePlaylistAsync("Test");

        await repo.AddToPlaylistAsync(pl.Id, b.Id);
        await repo.AddToPlaylistAsync(pl.Id, a.Id);
        await repo.AddToPlaylistAsync(pl.Id, b.Id); // dubbel

        Assert.Equal([b.Id, a.Id], await repo.GetPlaylistTrackIdsAsync(pl.Id));
    }

    [Fact]
    public async Task Game_Rescan_DoesNotCreateDuplicates()
    {
        var repo = new GameRepository(new AuroraDatabase(_file));
        var g = new Game { Name = "Portal 2", Source = "Steam", LaunchTarget = "steam://rungameid/620" };
        await repo.AddOrUpdateAsync(g);
        await repo.AddOrUpdateAsync(new Game { Name = "Portal 2", Source = "Steam", LaunchTarget = "steam://rungameid/620" });
        Assert.Single(await repo.GetAllAsync());
    }
}
